import { models } from "@web/../tests/web_test_helpers";


export class SaleOrder extends models.ServerModel {
    _name = "sale.order";
}
