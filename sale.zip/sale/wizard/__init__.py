# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import base_document_layout
from . import mail_compose_message
from . import mass_cancel_orders
from . import payment_link_wizard
from . import payment_provider_onboarding_wizard
from . import res_config_settings
from . import sale_make_invoice_advance
from . import sale_order_cancel
from . import sale_order_discount
