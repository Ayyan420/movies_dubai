# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import combo_configurator
from . import portal
from . import product_configurator
